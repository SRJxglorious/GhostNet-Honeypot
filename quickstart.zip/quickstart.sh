#!/bin/bash

###############################################################################
# Honeypot System - Quick Start Script
# Automated setup and deployment
###############################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
HONEYPOT_DIR="${HONEYPOT_DIR:-.}"
HONEYPOT_USER="${HONEYPOT_USER:-honeypot}"
INSTALL_MONGODB="${INSTALL_MONGODB:-true}"
USE_DOCKER="${USE_DOCKER:-false}"

###############################################################################
# Helper Functions
###############################################################################

print_header() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}! $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

check_command() {
    if command -v "$1" &> /dev/null; then
        print_success "$1 found"
        return 0
    else
        print_error "$1 not found"
        return 1
    fi
}

###############################################################################
# System Requirements Check
###############################################################################

check_requirements() {
    print_header "Checking System Requirements"
    
    echo ""
    print_info "Checking for required commands..."
    
    local missing=0
    
    if ! check_command "python3"; then
        missing=$((missing + 1))
        print_error "Python 3 is required. Install with: sudo apt-get install python3"
    fi
    
    if ! check_command "pip3"; then
        missing=$((missing + 1))
        print_error "pip3 is required. Install with: sudo apt-get install python3-pip"
    fi
    
    if ! check_command "git"; then
        print_warning "git not found (optional)"
    fi
    
    echo ""
    
    # Check Python version
    if command -v python3 &> /dev/null; then
        PY_VERSION=$(python3 --version | cut -d' ' -f2)
        print_info "Python version: $PY_VERSION"
    fi
    
    if [ $missing -gt 0 ]; then
        print_error "Missing required dependencies. Please install and try again."
        exit 1
    fi
    
    echo ""
    print_success "All system requirements met!"
}

###############################################################################
# Directory Setup
###############################################################################

setup_directories() {
    print_header "Setting Up Directories"
    
    echo ""
    
    # Create main directory
    if [ ! -d "$HONEYPOT_DIR" ]; then
        mkdir -p "$HONEYPOT_DIR"
        print_success "Created honeypot directory: $HONEYPOT_DIR"
    else
        print_info "Using existing directory: $HONEYPOT_DIR"
    fi
    
    # Create subdirectories
    mkdir -p "$HONEYPOT_DIR/logs"
    print_success "Created logs directory"
    
    mkdir -p "$HONEYPOT_DIR/data"
    print_success "Created data directory"
    
    mkdir -p "$HONEYPOT_DIR/config"
    print_success "Created config directory"
    
    # Set permissions
    chmod 755 "$HONEYPOT_DIR"
    echo ""
    print_success "Directory structure created"
}

###############################################################################
# Python Dependencies
###############################################################################

install_dependencies() {
    print_header "Installing Python Dependencies"
    
    echo ""
    print_info "Upgrading pip..."
    pip3 install --upgrade pip setuptools wheel > /dev/null 2>&1
    print_success "pip upgraded"
    
    echo ""
    print_info "Installing required packages..."
    
    # Install packages
    pip3 install flask==2.3.2 flask-cors==4.0.0 > /dev/null 2>&1
    print_success "Flask and Flask-CORS installed"
    
    pip3 install pymongo==4.4.1 > /dev/null 2>&1
    print_success "PyMongo installed"
    
    # Optional packages
    pip3 install elasticsearch==8.8.2 > /dev/null 2>&1
    print_success "Elasticsearch client installed"
    
    echo ""
    print_success "All Python dependencies installed"
}

###############################################################################
# MongoDB Setup
###############################################################################

setup_mongodb() {
    if [ "$INSTALL_MONGODB" != "true" ]; then
        print_info "MongoDB installation skipped"
        return 0
    fi
    
    print_header "Setting Up MongoDB"
    
    echo ""
    
    # Check if MongoDB is already installed
    if check_command "mongo"; then
        print_info "MongoDB is already installed"
        
        # Check if running
        if systemctl is-active --quiet mongodb; then
            print_success "MongoDB is running"
        else
            print_warning "MongoDB is installed but not running"
            print_info "Starting MongoDB..."
            sudo systemctl start mongodb
            sudo systemctl enable mongodb
            print_success "MongoDB started"
        fi
        return 0
    fi
    
    # Check if Docker is available
    if check_command "docker"; then
        print_info "Docker found - using Docker for MongoDB"
        
        if [ ! "$(docker ps -q -f name=honeypot-mongo)" ]; then
            print_info "Starting MongoDB container..."
            docker run -d \
                --name honeypot-mongo \
                -p 27017:27017 \
                -v honeypot_data:/data/db \
                mongo:latest > /dev/null 2>&1
            print_success "MongoDB container started"
        else
            print_info "MongoDB container already running"
        fi
        return 0
    fi
    
    # Try native installation
    print_info "Installing MongoDB natively..."
    
    if [ -f /etc/debian_version ]; then
        print_info "Detected Debian-based system"
        sudo apt-get update > /dev/null 2>&1
        sudo apt-get install -y mongodb > /dev/null 2>&1
    elif [ -f /etc/redhat-release ]; then
        print_info "Detected RedHat-based system"
        sudo yum install -y mongodb > /dev/null 2>&1
    else
        print_warning "Cannot auto-detect package manager"
        print_warning "Please install MongoDB manually"
        return 1
    fi
    
    # Start MongoDB
    sudo systemctl start mongodb > /dev/null 2>&1
    sudo systemctl enable mongodb > /dev/null 2>&1
    print_success "MongoDB installed and started"
}

###############################################################################
# File Deployment
###############################################################################

verify_files() {
    print_header "Verifying Required Files"
    
    echo ""
    
    local files=(
        "honeypot_server.py"
        "storage_manager.py"
        "api_server.py"
        "dashboard.html"
    )
    
    local missing_files=0
    
    for file in "${files[@]}"; do
        if [ -f "$HONEYPOT_DIR/$file" ]; then
            print_success "$file found"
        else
            print_warning "$file not found in $HONEYPOT_DIR"
            missing_files=$((missing_files + 1))
        fi
    done
    
    echo ""
    
    if [ $missing_files -gt 0 ]; then
        print_warning "$missing_files file(s) missing - copy them manually or clone the repository"
    else
        print_success "All required files present"
    fi
}

###############################################################################
# Permission Setup
###############################################################################

setup_permissions() {
    print_header "Setting Up Permissions"
    
    echo ""
    
    # Make scripts executable
    chmod +x "$HONEYPOT_DIR/honeypot_server.py" > /dev/null 2>&1 || true
    chmod +x "$HONEYPOT_DIR/api_server.py" > /dev/null 2>&1 || true
    print_success "Scripts made executable"
    
    # Create honeypot user (if running as root)
    if [ "$EUID" -eq 0 ]; then
        if ! id "$HONEYPOT_USER" &> /dev/null; then
            useradd -r -s /bin/bash -d "$HONEYPOT_DIR" "$HONEYPOT_USER"
            print_success "Created honeypot user: $HONEYPOT_USER"
        fi
        
        chown -R "$HONEYPOT_USER:$HONEYPOT_USER" "$HONEYPOT_DIR"
        print_success "Set ownership to $HONEYPOT_USER"
    else
        print_info "Skipping user creation (not running as root)"
    fi
    
    echo ""
    print_success "Permissions configured"
}

###############################################################################
# Systemd Setup
###############################################################################

setup_systemd() {
    print_header "Setting Up Systemd Services (Optional)"
    
    echo ""
    print_info "This step requires root privileges"
    
    read -p "Install systemd services? (y/n) " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if [ "$EUID" -ne 0 ]; then
            print_warning "Not running as root, skipping systemd setup"
            print_info "To install manually, run: sudo bash"
            return 1
        fi
        
        # Create honeypot service
        cat > /etc/systemd/system/honeypot.service << EOF
[Unit]
Description=Honeypot Server
After=network.target
Wants=honeypot-api.service

[Service]
Type=simple
User=$HONEYPOT_USER
WorkingDirectory=$HONEYPOT_DIR
ExecStart=/usr/bin/python3 $HONEYPOT_DIR/honeypot_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
        
        print_success "Created honeypot.service"
        
        # Create API service
        cat > /etc/systemd/system/honeypot-api.service << EOF
[Unit]
Description=Honeypot API Server
After=network.target honeypot.service
Wants=honeypot.service

[Service]
Type=simple
User=$HONEYPOT_USER
WorkingDirectory=$HONEYPOT_DIR
Environment="PYTHONUNBUFFERED=1"
ExecStart=/usr/bin/python3 $HONEYPOT_DIR/api_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
        
        print_success "Created honeypot-api.service"
        
        # Enable services
        systemctl daemon-reload
        systemctl enable honeypot honeypot-api
        print_success "Services enabled"
        
        echo ""
        print_info "To start services, run:"
        print_info "  sudo systemctl start honeypot"
        print_info "  sudo systemctl start honeypot-api"
    else
        print_info "Systemd setup skipped"
    fi
}

###############################################################################
# Testing
###############################################################################

test_installation() {
    print_header "Testing Installation"
    
    echo ""
    
    # Test Python
    print_info "Testing Python imports..."
    python3 -c "import flask; import pymongo" 2> /dev/null
    if [ $? -eq 0 ]; then
        print_success "Python dependencies working"
    else
        print_error "Python import test failed"
        return 1
    fi
    
    # Test MongoDB connection
    if check_command "mongo"; then
        print_info "Testing MongoDB connection..."
        mongo --eval "db.version()" > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            print_success "MongoDB connection successful"
        else
            print_warning "MongoDB connection failed (may still work with local storage)"
        fi
    fi
    
    echo ""
    print_success "Installation test completed"
}

###############################################################################
# Configuration Files
###############################################################################

create_config() {
    print_header "Creating Configuration Files"
    
    echo ""
    
    # Create config template
    cat > "$HONEYPOT_DIR/config/config.json" << 'EOF'
{
  "honeypot": {
    "ssh_port": 2222,
    "http_port": 8080,
    "ftp_port": 2121,
    "log_dir": "./logs"
  },
  "storage": {
    "type": "mongodb",
    "mongodb": {
      "uri": "mongodb://localhost:27017",
      "db_name": "honeypot"
    },
    "local": {
      "path": "./data"
    }
  },
  "api": {
    "host": "0.0.0.0",
    "port": 5000,
    "debug": false
  },
  "logging": {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  }
}
EOF
    
    print_success "Created config.json"
    echo ""
}

###############################################################################
# Final Summary
###############################################################################

print_summary() {
    print_header "Installation Summary"
    
    echo ""
    echo "Honeypot system installed successfully!"
    echo ""
    echo "Location: $HONEYPOT_DIR"
    echo ""
    echo "Next steps:"
    echo "1. Review configuration: $HONEYPOT_DIR/config/config.json"
    echo "2. Start honeypot server:"
    echo "   python3 $HONEYPOT_DIR/honeypot_server.py"
    echo "3. Start API server (in another terminal):"
    echo "   python3 $HONEYPOT_DIR/api_server.py"
    echo "4. Access dashboard:"
    echo "   http://localhost:5000"
    echo ""
    echo "Ports in use:"
    echo "  2222 - SSH honeypot"
    echo "  8080 - HTTP honeypot"
    echo "  2121 - FTP honeypot"
    echo "  5000 - API & Dashboard"
    echo ""
    echo "For more information, see: SETUP_GUIDE.md"
    echo ""
    print_success "Ready to deploy!"
}

###############################################################################
# Main Execution
###############################################################################

main() {
    clear
    
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║          Honeypot System - Quick Start Installation           ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    
    check_requirements
    setup_directories
    install_dependencies
    setup_mongodb
    verify_files
    setup_permissions
    setup_systemd
    test_installation
    create_config
    print_summary
}

# Run main
main
